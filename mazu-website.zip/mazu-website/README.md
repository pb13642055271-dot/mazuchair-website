# MAZU - Premium Folding Chairs

Corporate website for MAZU, a leading folding chair manufacturer based in Hebei, China.

## Quick Start

This is a **pure static HTML/CSS/JS** project — no build tools, no npm install, zero dependencies.

Just open `index.html` in a browser, or serve the folder with any static server:

```bash
# Using Python
python3 -m http.server 8080

# Using Node (npx)
npx serve .

# Using PHP
php -S localhost:8080
```

Then visit `http://localhost:8080`

---

## Features

- **7 Pages**: Home, About Us, Products, Product Detail, Case Studies, Blog, Contact
- **Responsive Design**: Mobile-first approach with breakpoints at 640px, 768px, 1024px, 1280px
- **Interactive Features**:
  - Navigation with dropdown product menu (5 categories with images)
  - Search modal (Cmd/Ctrl + K)
  - Inquiry/quote modal with form
  - Animated number counters
  - FAQ accordion
  - WhatsApp floating button
  - Back-to-top button
  - Scroll reveal animations
  - Product category filtering
  - Product gallery with thumbnails
  - Breadcrumb navigation
  - Horizontal timeline on About page
  - Market map visualization
- **SEO Ready**: Meta tags, Open Graph, sitemap.xml, robots.txt
- **Deployment Ready**: Pure HTML/CSS/JS, no build step required

## Tech Stack

- HTML5 (semantic markup)
- CSS3 (CSS Grid, Flexbox, CSS Variables, CSS Animations)
- Vanilla JavaScript (ES6+)
- Inter font (self-hosted via CDN mirror)

## Project Structure

```
/
├── index.html              # Homepage
├── about.html              # About Us
├── products.html           # Products listing
├── product-detail.html     # Product detail page (query param: ?id=product-id)
├── cases.html              # Case Studies / Portfolio
├── blog.html               # News & Blog
├── contact.html            # Contact page
├── robots.txt              # SEO robots file
├── sitemap.xml             # SEO sitemap
├── site.webmanifest        # PWA manifest
├── README.md               # This file
├── css/
│   └── style.css           # Main stylesheet (design system + components)
├── js/
│   ├── config.js           # Image base URL configuration
│   ├── data.js             # Product, case study, blog data (all content)
│   └── main.js             # Shared components and utilities
└── images/                 # All images (SVG placeholders included)
    ├── logo.svg
    ├── hero-factory.svg
    ├── hero-chairs.svg
    ├── factory.svg
    ├── warehouse.svg
    ├── showroom.svg
    ├── categories/         # 5 category images
    ├── products/           # 12 product images
    ├── cases/              # 6 case study images
    └── blog/               # 6 blog post images
```

---

## Deployment

### Vercel

1. Push this project to a GitHub repository
2. Go to vercel.com and import the repo
3. Framework preset: **Other** (static)
4. Build command: — (none, leave empty)
5. Output directory: `.` (root)
6. Deploy!

### Netlify

1. **Drag & Drop** (simplest): Drag the entire folder onto [app.netlify.com/drop](https://app.netlify.com/drop)
2. **Git-based**: Connect the repo with these settings:
   - Build command: — (none)
   - Publish directory: `.` (root)
3. Deploy!

### Cloudflare Pages

1. Connect your Git repository
2. Framework preset: **None**
3. Build command: — (none)
4. Build output directory: `/`
5. Deploy!

### GitHub Pages

1. Push to a GitHub repo
2. Go to Settings → Pages
3. Source: `Deploy from a branch`
4. Branch: `main` / `(root)`
5. Save

---

## Customization Guide

### Replacing Placeholder Images with Real Photos

The project ships with **SVG placeholder images** so it works out of the box. To use real product photos:

1. Replace each SVG file in `images/` with your real image (JPG or PNG recommended)
2. Update the filenames in `js/data.js` to match your new files

**Example:** Replace `images/products/product-1.svg` with `aerolite-white.jpg`, then in `js/data.js`:

```js
// Before
{ image: 'products/product-1.svg', ... }

// After
{ image: 'products/aerolite-white.jpg', ... }
```

### Using an External CDN for Images

If you prefer to host images on Cloudinary, Imgix, or S3:

1. Edit `js/config.js`:
```js
const MAZU_CONFIG = {
  imgBase: 'https://your-cdn.com/mazu-images/',
};
```

2. Update image paths in `js/data.js` accordingly (they're relative to `imgBase`).

### Branding & Colors

Edit CSS variables at the top of `css/style.css`:

```css
:root {
  --color-primary: #0A2540;       /* Navy blue - primary */
  --color-accent: #0066FF;        /* Bright blue - accent */
  --color-accent-light: #6BA5FF;  /* Light blue */
  --color-dark: #0A0A0A;          /* Black */
  --color-light: #F8F9FA;         /* Off white */
  /* ... and more */
}
```

### Products & Content

All content is defined in `js/data.js` as the `SITE_DATA` object:

- `SITE_DATA.products` — 12 products across 5 categories
- `SITE_DATA.categories` — 5 product categories
- `SITE_DATA.advantages` — 6 company advantages
- `SITE_DATA.partners` — 12 partner logos
- `SITE_DATA.faqs` — 8 FAQ items
- `SITE_DATA.timeline` — 5 timeline events
- `SITE_DATA.values` — 4 core values
- `SITE_DATA.cases` — 6 case studies
- `SITE_DATA.blogPosts` — 6 blog posts
- `SITE_DATA.images` — hero and section images

### Logo

Replace `images/logo.svg` with your actual logo file.

### WhatsApp Button

Edit the WhatsApp number and message in `js/main.js` (search for "whatsapp").

### Inquiry Form

The form is currently client-side only (shows a success message). To connect it to a real backend:

- **Vercel**: Use Vercel Serverless Functions or Formspree
- **Netlify**: Use Netlify Forms (add `netlify` attribute to the form tag)
- **Third-party**: Formspree, Basin, Getform, etc.

### SEO

- Page titles and meta descriptions are in each HTML file's `<head>`
- `sitemap.xml` — update with your domain
- `robots.txt` — update with your domain
- Open Graph tags are included for social sharing

---

## Product Detail Page

The product detail page (`product-detail.html`) reads the product ID from the URL query parameter:

```
product-detail.html?id=p-001
product-detail.html?id=p-005
```

The product data is fetched from `SITE_DATA.products` in `js/data.js`.

---

## Browser Support

- Chrome (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Edge (latest 2 versions)

## License

© 2026 MAZU Furniture Co., Ltd. All rights reserved.
