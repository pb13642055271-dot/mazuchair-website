#!/bin/bash
# This script generates SVG placeholder images for MAZU website
# Run this script from the images/ directory to create placeholders

mkdir -p categories products cases blog

# Brand logo placeholder
cat > logo.svg << 'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
  <rect width="400" height="400" fill="#ffffff"/>
  <text x="50%" y="48%" font-family="Arial, Helvetica, sans-serif" font-size="120" font-weight="800" fill="#0A2540" text-anchor="middle" dominant-baseline="middle" letter-spacing="-4">MAZU</text>
  <text x="50%" y="62%" font-family="Arial, Helvetica, sans-serif" font-size="16" font-weight="500" fill="#6C757D" text-anchor="middle" dominant-baseline="middle" letter-spacing="4">SEATING THE WORLD</text>
  <line x1="140" y1="260" x2="260" y2="260" stroke="#0066FF" stroke-width="3"/>
</svg>
SVGEOF

# Product category placeholders
declare -A categories=(
  ["plastic-chair"]="Plastic Chair"
  ["metal-chair"]="Metal Chair"
  ["upholstered-chair"]="Upholstered Chair"
  ["office-chair"]="Office Chair"
  ["table"]="Table"
)

for key in "${!categories[@]}"; do
  name="${categories[$key]}"
  cat > "categories/$key.svg" << SVGEOF
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#F8F9FA"/>
      <stop offset="100%" style="stop-color:#E9ECEF"/>
    </linearGradient>
  </defs>
  <rect width="800" height="600" fill="url(#bg)"/>
  <g transform="translate(400, 320)">
    <rect x="-80" y="-120" width="160" height="10" rx="5" fill="#0A2540"/>
    <rect x="-75" y="-120" width="8" height="160" rx="4" fill="#0A2540"/>
    <rect x="67" y="-120" width="8" height="160" rx="4" fill="#0A2540"/>
    <rect x="-60" y="40" width="120" height="10" rx="5" fill="#0A2540"/>
    <rect x="-80" y="40" width="10" height="80" rx="5" fill="#0A2540"/>
    <rect x="70" y="40" width="10" height="80" rx="5" fill="#0A2540"/>
  </g>
  <text x="50%" y="520" font-family="Arial, sans-serif" font-size="28" font-weight="700" fill="#0A2540" text-anchor="middle">$name</text>
  <text x="50%" y="560" font-family="Arial, sans-serif" font-size="14" fill="#6C757D" text-anchor="middle">Replace with product photo</text>
</svg>
SVGEOF
done

# Product placeholders (12 products)
product_names=(
  "AeroLite White Folding Chair"
  "VivaPro Red Event Chair"
  "EcoStack Armless Chair"
  "IronClad Heavy-Duty Chair"
  "UrbanMesh Black Frame Chair"
  "VelvetLux Padded Banquet Chair"
  "ComfortWeave Gray Cushion Chair"
  "ErgoFlex Mesh Office Chair"
  "ConferencePro Training Chair"
  "PureTop 6ft Folding Table"
  "RoundBanquet 5ft Table"
  "MiniCamp 4ft Bi-fold Table"
)

product_skus=(
  "MZ-PL-001" "MZ-PL-002" "MZ-PL-003"
  "MZ-MT-001" "MZ-MT-002"
  "MZ-UP-001" "MZ-UP-002"
  "MZ-OF-001" "MZ-OF-002"
  "MZ-TB-001" "MZ-TB-002" "MZ-TB-003"
)

colors=(
  "#ffffff,#F1F3F5" "#ff6b6b,#FA5252" "#8CE99A,#51CF66"
  "#343A40,#212529" "#495057,#343A40"
  "#dee2e6,#adb5bd" "#868e96,#495057"
  "#212529,#0A0A0A" "#343A40,#212529"
  "#ffffff,#E9ECEF" "#fff3bf,#ffec99"
  "#ffffff,#DEE2E6"
)

for i in "${!product_names[@]}"; do
  name="${product_names[$i]}"
  sku="${product_skus[$i]}"
  c="${colors[$i]}"
  c1=$(echo $c | cut -d',' -f1)
  c2=$(echo $c | cut -d',' -f2)
  filename="product-$((i+1)).svg"
  
  cat > "products/$filename" << SVGEOF
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:$c1"/>
      <stop offset="100%" style="stop-color:$c2"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="900" fill="url(#bg)"/>
  <g transform="translate(600, 450)" opacity="0.3">
    <rect x="-120" y="-180" width="240" height="15" rx="7" fill="#0A2540"/>
    <rect x="-110" y="-180" width="12" height="240" rx="6" fill="#0A2540"/>
    <rect x="98" y="-180" width="12" height="240" rx="6" fill="#0A2540"/>
    <rect x="-90" y="60" width="180" height="15" rx="7" fill="#0A2540"/>
    <rect x="-120" y="60" width="15" height="120" rx="7" fill="#0A2540"/>
    <rect x="105" y="60" width="15" height="120" rx="7" fill="#0A2540"/>
  </g>
  <text x="50%" y="750" font-family="Arial, sans-serif" font-size="32" font-weight="700" fill="#0A2540" text-anchor="middle">$name</text>
  <text x="50%" y="790" font-family="Arial, sans-serif" font-size="16" fill="#6C757D" text-anchor="middle" letter-spacing="2">$sku</text>
</svg>
SVGEOF
done

# Case study placeholders
case_names=(
  "Hilton Hotel Chain Supply"
  "Decathlon Outdoor Range"
  "Dubai Expo 2025"
  "WeWork Training Rooms"
  "UAE Ministry of Education"
  "Carrefour Private Label"
)

for i in "${!case_names[@]}"; do
  name="${case_names[$i]}"
  filename="case-$((i+1)).svg"
  
  cat > "cases/$filename" << SVGEOF
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0A2540"/>
      <stop offset="100%" style="stop-color:#1B3A5C"/>
    </linearGradient>
  </defs>
  <rect width="800" height="600" fill="url(#bg)"/>
  <g opacity="0.15" transform="translate(400, 300)">
    <circle cx="-150" cy="50" r="60" fill="#ffffff"/>
    <circle cx="-80" cy="-30" r="80" fill="#ffffff"/>
    <circle cx="0" cy="60" r="50" fill="#ffffff"/>
    <circle cx="80" cy="-40" r="70" fill="#ffffff"/>
    <circle cx="150" cy="50" r="55" fill="#ffffff"/>
  </g>
  <text x="50%" y="290" font-family="Arial, sans-serif" font-size="48" font-weight="800" fill="#ffffff" text-anchor="middle" opacity="0.9">${name% *}</text>
  <text x="50%" y="340" font-family="Arial, sans-serif" font-size="18" fill="#6BA5FF" text-anchor="middle" letter-spacing="3">CASE STUDY</text>
</svg>
SVGEOF
done

# Blog post placeholders
blog_names=(
  "Choosing Folding Chairs Guide"
  "Sustainable Materials"
  "Shipping Cost Reduction"
  "Quality Control Deep Dive"
  "Commercial Seating Trends"
  "Eco-Line Launch"
)

for i in "${!blog_names[@]}"; do
  name="${blog_names[$i]}"
  filename="blog-$((i+1)).svg"
  
  cat > "blog/$filename" << SVGEOF
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 450">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#1B3A5C"/>
      <stop offset="100%" style="stop-color:#0A2540"/>
    </linearGradient>
  </defs>
  <rect width="800" height="450" fill="url(#bg)"/>
  <g transform="translate(400, 225)" opacity="0.1">
    <rect x="-200" y="-80" width="400" height="8" rx="4" fill="#ffffff"/>
    <rect x="-200" y="-50" width="300" height="6" rx="3" fill="#ffffff"/>
    <rect x="-200" y="-20" width="350" height="6" rx="3" fill="#ffffff"/>
    <rect x="-200" y="10" width="280" height="6" rx="3" fill="#ffffff"/>
    <rect x="-200" y="40" width="320" height="6" rx="3" fill="#ffffff"/>
  </g>
  <text x="50%" y="235" font-family="Arial, sans-serif" font-size="28" font-weight="700" fill="#ffffff" text-anchor="middle">${name}</text>
</svg>
SVGEOF
done

# Hero placeholders
cat > hero-factory.svg << 'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">
  <defs>
    <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#0A2540"/>
      <stop offset="50%" style="stop-color:#1B3A5C"/>
      <stop offset="100%" style="stop-color:#2C4A7C"/>
    </linearGradient>
  </defs>
  <rect width="1920" height="1080" fill="url(#sky)"/>
  <g opacity="0.15" fill="#ffffff">
    <rect x="100" y="500" width="200" height="400"/>
    <rect x="330" y="400" width="280" height="500"/>
    <rect x="640" y="450" width="180" height="450"/>
    <rect x="850" y="350" width="320" height="550"/>
    <rect x="1200" y="420" width="250" height="480"/>
    <rect x="1480" y="480" width="200" height="420"/>
    <rect x="1710" y="520" width="150" height="380"/>
  </g>
  <g opacity="0.3" fill="#6BA5FF">
    <circle cx="300" cy="300" r="40"/>
    <circle cx="700" cy="200" r="60"/>
    <circle cx="1200" cy="280" r="45"/>
    <circle cx="1600" cy="220" r="55"/>
  </g>
  <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="64" font-weight="800" fill="#ffffff" text-anchor="middle" dominant-baseline="middle" opacity="0.9">MAZU</text>
  <text x="50%" y="56%" font-family="Arial, sans-serif" font-size="20" fill="#6BA5FF" text-anchor="middle" letter-spacing="8">SEATING THE WORLD WITH EXCELLENCE</text>
</svg>
SVGEOF

cat > hero-chairs.svg << 'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0A2540"/>
      <stop offset="100%" style="stop-color:#1B3A5C"/>
    </linearGradient>
  </defs>
  <rect width="1920" height="1080" fill="url(#bg)"/>
  <g transform="translate(960, 540)" opacity="0.3">
    <rect x="-300" y="-200" width="120" height="15" fill="#ffffff"/>
    <rect x="-295" y="-200" width="10" height="300" fill="#ffffff"/>
    <rect x="-185" y="-200" width="10" height="300" fill="#ffffff"/>
    <rect x="-280" y="100" width="100" height="15" fill="#ffffff"/>
    <rect x="-300" y="100" width="12" height="150" fill="#ffffff"/>
    <rect x="-188" y="100" width="12" height="150" fill="#ffffff"/>
  </g>
  <g transform="translate(760, 580)" opacity="0.2">
    <rect x="-120" y="-160" width="100" height="12" fill="#ffffff"/>
    <rect x="-115" y="-160" width="8" height="240" fill="#ffffff"/>
    <rect x="-27" y="-160" width="8" height="240" fill="#ffffff"/>
    <rect x="-100" y="80" width="80" height="12" fill="#ffffff"/>
  </g>
  <g transform="translate(1150, 560)" opacity="0.25">
    <rect x="-90" y="-140" width="80" height="10" fill="#ffffff"/>
    <rect x="-85" y="-140" width="6" height="200" fill="#ffffff"/>
    <rect x="-9" y="-140" width="6" height="200" fill="#ffffff"/>
    <rect x="-75" y="60" width="65" height="10" fill="#ffffff"/>
  </g>
</svg>
SVGEOF

cat > warehouse.svg << 'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#F1F3F5"/>
      <stop offset="100%" style="stop-color:#DEE2E6"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="800" fill="url(#bg)"/>
  <g opacity="0.3" fill="#ADB5BD">
    <rect x="50" y="200" width="150" height="500"/>
    <rect x="220" y="150" width="180" height="550"/>
    <rect x="420" y="180" width="160" height="520"/>
    <rect x="600" y="160" width="200" height="540"/>
    <rect x="820" y="190" width="170" height="510"/>
    <rect x="1010" y="210" width="140" height="490"/>
  </g>
  <g opacity="0.5" fill="#0A2540">
    <rect x="0" y="700" width="1200" height="100"/>
  </g>
  <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="36" font-weight="700" fill="#0A2540" text-anchor="middle" dominant-baseline="middle">Warehouse & Logistics</text>
</svg>
SVGEOF

cat > factory.svg << 'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#E9ECEF"/>
      <stop offset="100%" style="stop-color:#CED4DA"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="800" fill="url(#bg)"/>
  <g opacity="0.4" fill="#495057">
    <rect x="100" y="400" width="80" height="300"/>
    <rect x="220" y="350" width="100" height="350"/>
    <rect x="360" y="380" width="90" height="320"/>
    <rect x="490" y="340" width="110" height="360"/>
    <rect x="640" y="370" width="85" height="330"/>
    <rect x="765" y="360" width="95" height="340"/>
    <rect x="895" y="390" width="80" height="310"/>
    <rect x="1010" y="355" width="100" height="345"/>
  </g>
  <text x="50%" y="45%" font-family="Arial, sans-serif" font-size="36" font-weight="700" fill="#0A2540" text-anchor="middle" dominant-baseline="middle">Production Line</text>
</svg>
SVGEOF

cat > showroom.svg << 'SVGEOF'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 1500">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0A2540"/>
      <stop offset="100%" style="stop-color:#1B3A5C"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="1500" fill="url(#bg)"/>
  <g opacity="0.2" fill="#ffffff">
    <rect x="200" y="300" width="150" height="20" rx="10"/>
    <rect x="205" y="300" width="12" height="300"/>
    <rect x="338" y="300" width="12" height="300"/>
    <rect x="220" y="600" width="110" height="20" rx="10"/>
    <rect x="200" y="600" width="15" height="200"/>
    <rect x="335" y="600" width="15" height="200"/>
  </g>
  <g opacity="0.25" fill="#ffffff">
    <rect x="500" y="350" width="180" height="20" rx="10"/>
    <rect x="505" y="350" width="15" height="350"/>
    <rect x="665" y="350" width="15" height="350"/>
    <rect x="520" y="700" width="140" height="20" rx="10"/>
    <rect x="500" y="700" width="18" height="250"/>
    <rect x="662" y="700" width="18" height="250"/>
  </g>
  <g opacity="0.15" fill="#ffffff">
    <rect x="850" y="280" width="140" height="18" rx="9"/>
    <rect x="855" y="280" width="10" height="280"/>
    <rect x="980" y="280" width="10" height="280"/>
  </g>
  <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="48" font-weight="800" fill="#ffffff" text-anchor="middle" dominant-baseline="middle" opacity="0.9">Premium Collection</text>
</svg>
SVGEOF

echo "All placeholder images generated successfully!"
echo ""
echo "Files created:"
echo "  - logo.svg"
echo "  - hero-factory.svg"
echo "  - hero-chairs.svg"
echo "  - warehouse.svg"
echo "  - factory.svg"
echo "  - showroom.svg"
echo "  - categories/ (5 files)"
echo "  - products/ (12 files)"
echo "  - cases/ (6 files)"
echo "  - blog/ (6 files)"
