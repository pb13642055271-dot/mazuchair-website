// ============================================
// MAZU - Configuration
// ============================================

// Image base URL configuration
// - For production deployment on Vercel/Netlify, use 'images/' (local images folder)
// - For local development with external CDN, use the full CDN URL
const MAZU_CONFIG = {
  // Set to 'images/' for production (local images folder)
  // Set to full CDN URL for sandbox preview
  imgBase: 'images/',

  // Fallback: if images fail to load, use SVG gradient placeholders
  usePlaceholders: true,
};

// Note: For deployment, place your product images in the /images/ folder
// and update the image paths in js/data.js to match your filenames.
// Example: in data.js, change image: "static/aadkqvcc62wai_ve_miaoda"
// to image: "plastic-chair-01.jpg"
