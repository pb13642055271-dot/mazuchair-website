// ============================================
// MAZU - Image Data (Production Version)
// ============================================
// Use this data.js with local images in /images/ folder
// for deployment on Vercel / Netlify
// ============================================

const SITE_DATA = {
  company: {
    name: 'MAZU',
    slogan: 'Seating the World with Excellence',
    founded: 2010,
    location: 'Hebei, China',
    employees: '500+',
    annualOutput: '2M+',
    countries: '50+',
  },

  categories: [
    { id: 'plastic-chair', name: 'Plastic Chair', slug: 'plastic-chair', desc: 'Lightweight, durable, and weather-resistant seating solutions', image: 'categories/plastic-chair.svg' },
    { id: 'metal-chair', name: 'Metal Chair', slug: 'metal-chair', desc: 'Industrial-strength folding chairs for heavy-duty use', image: 'categories/metal-chair.svg' },
    { id: 'upholstered-chair', name: 'Upholstered Chair', slug: 'upholstered-chair', desc: 'Premium cushioned seating for comfort and elegance', image: 'categories/upholstered-chair.svg' },
    { id: 'office-chair', name: 'Office Chair', slug: 'office-chair', desc: 'Ergonomic folding office chairs for modern workspaces', image: 'categories/office-chair.svg' },
    { id: 'table', name: 'Table', slug: 'table', desc: 'Versatile folding tables for events, offices, and hospitality', image: 'categories/table.svg' },
  ],

  products: [
    {
      id: 'p-001', sku: 'MZ-PL-001', name: 'AeroLite White Folding Chair',
      category: 'plastic-chair', categoryName: 'Plastic Chair', badge: 'New',
      description: 'Ultra-lightweight polypropylene folding chair with ergonomic contoured design. Perfect for outdoor events, banquet halls, and rental businesses.',
      image: 'products/product-1.svg', images: ['products/product-1.svg','products/product-1.svg','products/product-1.svg','products/product-1.svg'],
      dimensions: '450 × 500 × 800 mm', weight: 3.2, packingDimensions: '980 × 480 × 480 mm (50 pcs/ctn)', packingWeight: 165,
      materials: 'PP Plastic, Steel Tube', deliveryTime: '15-20 days', containerLoading: '5,400 pcs / 20ft; 11,200 pcs / 40HQ', moq: '200 pcs', warranty: '2 years',
    },
    {
      id: 'p-002', sku: 'MZ-PL-002', name: 'VivaPro Red Event Chair',
      category: 'plastic-chair', categoryName: 'Plastic Chair', badge: 'Popular',
      description: 'High-impact resin folding chair in vibrant red. UV-stabilized for outdoor use, with a weight capacity of 250 kg.',
      image: 'products/product-2.svg', images: ['products/product-2.svg','products/product-2.svg','products/product-2.svg','products/product-2.svg'],
      dimensions: '460 × 520 × 810 mm', weight: 3.5, packingDimensions: '990 × 490 × 490 mm (48 pcs/ctn)', packingWeight: 172,
      materials: 'HDPE Plastic, Powder-coated Steel', deliveryTime: '15-20 days', containerLoading: '5,200 pcs / 20ft; 10,800 pcs / 40HQ', moq: '200 pcs', warranty: '2 years',
    },
    {
      id: 'p-003', sku: 'MZ-PL-003', name: 'EcoStack Armless Chair',
      category: 'plastic-chair', categoryName: 'Plastic Chair',
      description: 'Stackable armless folding chair made from 100% recycled plastic. Certified eco-friendly for sustainable procurement.',
      image: 'products/product-3.svg', images: ['products/product-3.svg','products/product-3.svg','products/product-3.svg','products/product-3.svg'],
      dimensions: '440 × 490 × 790 mm', weight: 2.9, packingDimensions: '970 × 470 × 470 mm (55 pcs/ctn)', packingWeight: 163,
      materials: 'Recycled PP Plastic, Galvanized Steel', deliveryTime: '20-25 days', containerLoading: '5,800 pcs / 20ft; 12,000 pcs / 40HQ', moq: '300 pcs', warranty: '2 years',
    },
    {
      id: 'p-004', sku: 'MZ-MT-001', name: 'IronClad Heavy-Duty Chair',
      category: 'metal-chair', categoryName: 'Metal Chair', badge: 'Best Seller',
      description: 'Commercial-grade steel frame folding chair with reinforced cross-bracing. Designed for high-traffic venues and rental fleets.',
      image: 'products/product-4.svg', images: ['products/product-4.svg','products/product-4.svg','products/product-4.svg','products/product-4.svg'],
      dimensions: '470 × 520 × 830 mm', weight: 4.8, packingDimensions: '1000 × 500 × 500 mm (40 pcs/ctn)', packingWeight: 198,
      materials: 'Q195 Steel Tube, Textilene Mesh', deliveryTime: '18-23 days', containerLoading: '3,800 pcs / 20ft; 8,000 pcs / 40HQ', moq: '100 pcs', warranty: '3 years',
    },
    {
      id: 'p-005', sku: 'MZ-MT-002', name: 'UrbanMesh Black Frame Chair',
      category: 'metal-chair', categoryName: 'Metal Chair',
      description: 'Sleek matte-black metal frame with breathable mesh seat and back. Modern aesthetic for cafes, co-working spaces, and events.',
      image: 'products/product-5.svg', images: ['products/product-5.svg','products/product-5.svg','products/product-5.svg','products/product-5.svg'],
      dimensions: '460 × 510 × 820 mm', weight: 4.2, packingDimensions: '990 × 490 × 490 mm (45 pcs/ctn)', packingWeight: 195,
      materials: 'Powder-coated Steel, PVC-coated Polyester Mesh', deliveryTime: '15-20 days', containerLoading: '4,200 pcs / 20ft; 8,800 pcs / 40HQ', moq: '150 pcs', warranty: '2 years',
    },
    {
      id: 'p-006', sku: 'MZ-UP-001', name: 'VelvetLux Padded Banquet Chair',
      category: 'upholstered-chair', categoryName: 'Upholstered Chair', badge: 'Premium',
      description: 'Luxurious velvet-upholstered folding chair with high-density foam cushioning. Ideal for weddings, galas, and upscale events.',
      image: 'products/product-6.svg', images: ['products/product-6.svg','products/product-6.svg','products/product-6.svg','products/product-6.svg'],
      dimensions: '480 × 550 × 860 mm', weight: 6.5, packingDimensions: '1020 × 530 × 530 mm (25 pcs/ctn)', packingWeight: 170,
      materials: 'Velvet Fabric, 40D High-density Foam, Steel Frame', deliveryTime: '20-25 days', containerLoading: '2,400 pcs / 20ft; 5,000 pcs / 40HQ', moq: '100 pcs', warranty: '2 years',
    },
    {
      id: 'p-007', sku: 'MZ-UP-002', name: 'ComfortWeave Gray Cushion Chair',
      category: 'upholstered-chair', categoryName: 'Upholstered Chair',
      description: 'Premium fabric-upholstered folding chair with medium-firm cushion. Stain-resistant treatment for commercial use.',
      image: 'products/product-7.svg', images: ['products/product-7.svg','products/product-7.svg','products/product-7.svg','products/product-7.svg'],
      dimensions: '470 × 540 × 850 mm', weight: 5.8, packingDimensions: '1010 × 520 × 520 mm (28 pcs/ctn)', packingWeight: 168,
      materials: 'Linen-blend Fabric, 35D Foam, Steel Tube', deliveryTime: '18-23 days', containerLoading: '2,700 pcs / 20ft; 5,600 pcs / 40HQ', moq: '120 pcs', warranty: '2 years',
    },
    {
      id: 'p-008', sku: 'MZ-OF-001', name: 'ErgoFlex Mesh Office Chair',
      category: 'office-chair', categoryName: 'Office Chair', badge: 'New',
      description: 'Ergonomic folding office chair with lumbar support and breathable mesh back. Adjustable height and 360° swivel base.',
      image: 'products/product-8.svg', images: ['products/product-8.svg','products/product-8.svg','products/product-8.svg','products/product-8.svg'],
      dimensions: '580 × 600 × 1050 mm', weight: 12.5, packingDimensions: '620 × 280 × 620 mm (1 pc/ctn)', packingWeight: 14.5,
      materials: 'Nylon Mesh, PU Leather Seat, Nylon Base, Gas Lift', deliveryTime: '20-25 days', containerLoading: '500 pcs / 20ft; 1,050 pcs / 40HQ', moq: '50 pcs', warranty: '3 years',
    },
    {
      id: 'p-009', sku: 'MZ-OF-002', name: 'ConferencePro Training Chair',
      category: 'office-chair', categoryName: 'Office Chair',
      description: 'Folding training chair with tablet arm and under-seat storage. Perfect for conference rooms, training centers, and classrooms.',
      image: 'products/product-9.svg', images: ['products/product-9.svg','products/product-9.svg','products/product-9.svg','products/product-9.svg'],
      dimensions: '560 × 580 × 880 mm', weight: 8.5, packingDimensions: '950 × 600 × 300 mm (6 pcs/ctn)', packingWeight: 54,
      materials: 'Fabric Upholstery, Plywood Tablet, Steel Frame', deliveryTime: '18-23 days', containerLoading: '800 pcs / 20ft; 1,700 pcs / 40HQ', moq: '80 pcs', warranty: '2 years',
    },
    {
      id: 'p-010', sku: 'MZ-TB-001', name: 'PureTop 6ft Folding Table',
      category: 'table', categoryName: 'Table', badge: 'Best Seller',
      description: 'Heavy-duty 6-foot folding table with HDPE top and steel frame. Weather-resistant for indoor and outdoor use.',
      image: 'products/product-10.svg', images: ['products/product-10.svg','products/product-10.svg','products/product-10.svg','products/product-10.svg'],
      dimensions: '1830 × 760 × 740 mm', weight: 12.8, packingDimensions: '920 × 770 × 90 mm (1 pc/ctn)', packingWeight: 14,
      materials: 'HDPE Tabletop, Powder-coated Steel Frame', deliveryTime: '15-20 days', containerLoading: '360 pcs / 20ft; 760 pcs / 40HQ', moq: '50 pcs', warranty: '3 years',
    },
    {
      id: 'p-011', sku: 'MZ-TB-002', name: 'RoundBanquet 5ft Table',
      category: 'table', categoryName: 'Table',
      description: 'Round folding banquet table with 5ft diameter. Seats 8 people comfortably. Ideal for weddings, banquets, and catering events.',
      image: 'products/product-11.svg', images: ['products/product-11.svg','products/product-11.svg','products/product-11.svg','products/product-11.svg'],
      dimensions: '1520 × 1520 × 740 mm', weight: 15.5, packingDimensions: '1540 × 770 × 90 mm (1 pc/ctn)', packingWeight: 17,
      materials: 'PVC Laminated Plywood, Steel Frame, Edge Banding', deliveryTime: '18-23 days', containerLoading: '250 pcs / 20ft; 520 pcs / 40HQ', moq: '30 pcs', warranty: '2 years',
    },
    {
      id: 'p-012', sku: 'MZ-TB-003', name: 'MiniCamp 4ft Bi-fold Table',
      category: 'table', categoryName: 'Table', badge: 'New',
      description: 'Compact 4ft bi-fold folding table with carry handle. Lightweight and portable for trade shows, markets, and outdoor activities.',
      image: 'products/product-12.svg', images: ['products/product-12.svg','products/product-12.svg','products/product-12.svg','products/product-12.svg'],
      dimensions: '1220 × 610 × 740 mm', weight: 8.5, packingDimensions: '620 × 620 × 90 mm (1 pc/ctn)', packingWeight: 9.5,
      materials: 'HDPE Tabletop, Aluminum Frame', deliveryTime: '15-20 days', containerLoading: '720 pcs / 20ft; 1,500 pcs / 40HQ', moq: '100 pcs', warranty: '2 years',
    },
  ],

  advantages: [
    { icon: 'factory', title: 'Factory-Direct Pricing', desc: 'No middlemen. Buy straight from our Hebei factory for the best landed cost and transparent pricing.' },
    { icon: 'capacity', title: 'Massive Capacity', desc: 'Over 20,000 pieces produced every day across a 50,000 m² production facility with automated lines.' },
    { icon: 'delivery', title: 'Reliable Lead Times', desc: 'Standard orders ship in 15–25 days, with dedicated production lines for high-volume contracts.' },
    { icon: 'design', title: 'Design & Material R&D', desc: 'In-house designers and material labs developing durable, modern furniture with the latest materials.' },
    { icon: 'quality', title: 'Certified Quality', desc: 'ISO 9001 certified with full QC from raw pellets to palletized export. Every batch fully inspected.' },
    { icon: 'global', title: 'Global Service', desc: 'Multilingual sales and logistics support across Europe, the Middle East, and the Americas.' },
  ],

  partners: [
    'Decathlon', 'IKEA', 'Walmart', 'Carrefour', 'Lidl', 'Aldi',
    'Staples', 'Office Depot', 'Coca-Cola', 'PepsiCo', 'Marriott', 'Hilton',
  ],

  markets: [
    { region: 'Europe', countries: '25+ countries', flag: '🇪🇺' },
    { region: 'Middle East', countries: '12+ countries', flag: '🇦🇪' },
    { region: 'Americas', countries: '15+ countries', flag: '🇺🇸' },
  ],

  faqs: [
    { q: 'What is your minimum order quantity (MOQ)?', a: 'Our standard MOQ is 100 pieces per model. For first-time clients, we can offer a lower trial MOQ of 50 pieces for selected models. Mixed-container orders with multiple SKUs are also welcome — contact our sales team for a customized quote.' },
    { q: 'How long does production and delivery take?', a: 'Standard orders typically ship within 15–25 days depending on the model and quantity. Large-volume or custom orders may take 25–35 days. Sea freight to European ports takes approximately 28–35 days, while Middle East destinations take 15–20 days. We provide full tracking and regular updates.' },
    { q: 'Can I customize the product — colors, logo, materials?', a: 'Absolutely. We offer extensive customization including custom colors (Pantone matching), logo printing/embroidery, custom fabric/material selection, and even full product development from your sketches or samples. Our R&D team handles everything from prototyping to tooling. MOQ for custom models starts at 500 pieces.' },
    { q: 'What certifications do you have?', a: 'MAZU is ISO 9001:2015 certified. Our products comply with EN 16139 (strength and durability), REACH (EU chemical regulation), and BIFMA X5.1 standards. We can provide test reports and certification documents upon request. Specific market certifications (e.g., SGS, TÜV) are available for premium models.' },
    { q: 'How do you handle quality control?', a: 'We implement a 3-step QC process: raw material inspection upon arrival, in-line quality checks during production, and 100% final inspection before packaging. Our QC team of 30+ inspectors monitors every production line. We welcome third-party inspections (SGS, Intertek, etc.) at the client\'s request.' },
    { q: 'What payment terms do you accept?', a: 'We accept T/T (30% deposit, 70% before shipment), L/C at sight, and for established clients, O/A 30–60 days. New clients start with T/T terms. All payments are processed through our verified company bank account. We do not accept personal payment methods.' },
    { q: 'Do you provide samples? How long does it take?', a: 'Yes, we provide samples. Standard samples are typically ready in 3–5 working days. Custom samples (with logo or color changes) take 7–10 working days. Sample fees are charged upfront but are fully refundable upon placing a bulk order. We ship samples via DHL, FedEx, or your preferred courier.' },
    { q: 'What warranty do you offer?', a: 'We offer a 2-year standard warranty on all folding chairs against manufacturing defects, and 3 years on premium metal-framed models. Warranty covers structural integrity, frame welding, and hardware. Normal wear and tear, misuse, or damage from improper assembly are not covered. We stand behind our products and provide replacement parts if needed.' },
  ],

  timeline: [
    { year: '2010', title: 'Founded in Hebei', desc: 'Started as a small folding-chair workshop serving local and regional markets.' },
    { year: '2014', title: 'Product line expanded', desc: 'Added tables and office chairs; the team grew past 200 employees.' },
    { year: '2018', title: 'Certified and exporting', desc: 'Achieved ISO 9001 and shipped our first containers to Europe and the Middle East.' },
    { year: '2022', title: 'Global scale', desc: 'Annual output surpassed 2 million units, serving 50+ countries worldwide.' },
    { year: '2026', title: 'Building what is next', desc: 'Investing in sustainable materials and global R&D for the decade ahead.' },
  ],

  values: [
    { icon: 'I', title: 'Integrity', desc: 'We build every partnership on honesty, transparency, and keeping our word.' },
    { icon: 'Q', title: 'Quality', desc: 'Rigorous standards at every step, from raw material to finished product.' },
    { icon: 'In', title: 'Innovation', desc: 'Continuous R&D in design, materials, and manufacturing efficiency.' },
    { icon: 'P', title: 'Partnership', desc: 'Your success is our success. We grow together with the clients we serve.' },
  ],

  cases: [
    { id: 'c-001', tag: 'Hospitality', title: 'Hilton Hotel Chain — 5,000 Chair Supply', desc: 'Supplied premium banquet chairs across 12 Hilton properties in the Middle East with custom embroidery.', image: 'cases/case-1.svg' },
    { id: 'c-002', tag: 'Retail', title: 'Decathlon Exclusive Outdoor Range', desc: 'Co-developed a line of outdoor folding chairs for Decathlon\'s 200+ European stores.', image: 'cases/case-2.svg' },
    { id: 'c-003', tag: 'Events', title: 'Dubai Expo 2025 Seating Solution', desc: 'Delivered 8,000 folding chairs and 1,200 tables for the Dubai World Expo venues.', image: 'cases/case-3.svg' },
    { id: 'c-004', tag: 'Office', title: 'WeWork — Training Room Furniture', desc: 'Furnished 35 WeWork locations across Europe with ergonomic folding training chairs.', image: 'cases/case-4.svg' },
    { id: 'c-005', tag: 'Education', title: 'UAE Ministry of Education', desc: 'Supplied 12,000 school folding chairs across 80 educational institutions in the UAE.', image: 'cases/case-5.svg' },
    { id: 'c-006', tag: 'Retail', title: 'Carrefour Private Label Program', desc: 'Developed and manufactured a private-label folding furniture range for Carrefour Middle East.', image: 'cases/case-6.svg' },
  ],

  blogPosts: [
    { id: 'b-001', title: 'How to Choose the Right Folding Chairs for Your Event Rental Business', category: 'Guide', date: 'August 15, 2026', excerpt: 'A comprehensive guide to selecting folding chairs that balance durability, aesthetics, and ROI for rental companies.', image: 'blog/blog-1.svg', featured: true },
    { id: 'b-002', title: 'Sustainable Materials in Folding Furniture: What Buyers Need to Know', category: 'Industry', date: 'August 8, 2026', excerpt: 'Exploring recycled plastics, FSC wood, and other eco-friendly materials reshaping the folding furniture industry.', image: 'blog/blog-2.svg' },
    { id: 'b-003', title: '5 Ways to Reduce Shipping Costs for Bulk Furniture Orders', category: 'Tips', date: 'July 28, 2026', excerpt: 'Smart container loading, product design optimization, and logistics strategies to lower your landed cost.', image: 'blog/blog-3.svg' },
    { id: 'b-004', title: 'Quality Control in Chinese Furniture Manufacturing: A Deep Dive', category: 'Industry', date: 'July 15, 2026', excerpt: 'An inside look at MAZU\'s 3-step quality control process from raw material inspection to final export.', image: 'blog/blog-4.svg' },
    { id: 'b-005', title: 'Trends in Commercial Seating: What Hotels and Venues Want in 2026', category: 'Trends', date: 'July 1, 2026', excerpt: 'From minimalist design to sustainability, discover the key trends driving commercial seating purchases this year.', image: 'blog/blog-5.svg' },
    { id: 'b-006', title: 'MAZU Launches New Eco-Line of Recycled Plastic Chairs', category: 'News', date: 'June 20, 2026', excerpt: 'Introducing our latest collection of eco-friendly folding chairs made from 100% recycled polypropylene.', image: 'blog/blog-6.svg' },
  ],

  // Hero & section images
  images: {
    heroFactory: 'hero-factory.svg',
    heroChairs: 'hero-chairs.svg',
    factory: 'factory.svg',
    warehouse: 'warehouse.svg',
    showroom: 'showroom.svg',
    logo: 'logo.svg',
  },
};
